import math
print( math.factorial(6))














print("\n\n")
#==================== dicionario ================================#
classe = {"ana": 4.5,
         "beatriz": 6.5,
         "geraldo": 1.0,
         "jose": 10.0,
         "maria": 9.5}
notas = classe.values()
media = sum(notas)/5
print("a media da classe e ",media)






dic = {"salgado": 4.50,
"lanche":6.50,
"suco":3.00,
"refrigerante": 3.50,
"doce":1.00}
print(dic)









print("\n\n")
#===============================================================#
D = {"arroz": 17.30,"feijao":12.50,"carne":23.90,"alface": 3.40}
print(D)

D["carne"] = 25.0
D["tomate"] = 8.80
print(D)





print("\n\n")
#======================TUPLAS======================#
T = (10,20,30,40,50)
a,b,c,d,e = T
print("a =",a,"b =",b)
print("d + e =",d+e)



print("\n\n")
 #-------------- pratica com lista -------------------# 
L = [5, 7, 2, 9, 4, 1, 3]
print("lista = ",L)
print("o tamanho da lista = é ",len(L))
print("o maior elemento da lista é ",max(L))
print("o menor elemneto da lista é",min(L))
print("a soma dos elementos da lista é ",sum(L))
L.sort()
print("a soma de ordem crescente: ",L)
L.reverse()
print("lista em ordem decrescente: ",L)